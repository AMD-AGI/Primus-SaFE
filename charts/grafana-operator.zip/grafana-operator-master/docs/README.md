# Grafana-operator

The docs folder contain all the grafana-operator documentation.
It's a soft link to our hugo docs and our homepage [https://grafana-operator.github.io/grafana-operator/](https://grafana-operator.github.io/grafana-operator/) which automatically gets update when any changes is done in these files.

Feel free to contribute to the docs if you feel that something is missing, you can find more information on how to contribute under [CONTRIBUTING.md](https://github.com/grafana/grafana-operator/blob/master/CONTRIBUTING.md).
