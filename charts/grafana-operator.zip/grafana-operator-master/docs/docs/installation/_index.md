---
title: "Installation"
linkTitle: "Installation"
weight: 10
---

The grafana-operator supports multiple different installation methods.

- Helm
- Kustomize
- Openshift OLM
