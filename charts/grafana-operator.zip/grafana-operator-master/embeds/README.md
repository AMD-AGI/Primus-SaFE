# Embeds

This package contains static information compiled into the binary at build time.

# Grafonnet

The Grafonnet Jsonnet is used to allow users to define their dashboards using the jsonnet framework.

# Version

The `Version` variable is set during production builds by `ko`. Configuration for this can be found in `.ko.yaml`
