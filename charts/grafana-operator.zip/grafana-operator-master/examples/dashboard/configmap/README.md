---
title: "Dashboard from ConfigMap"
linkTitle: "Dashboard from ConfigMap"
---

Shows how to obtain the dashboard definition (json) from a key in a ConfigMap in the same namespace as the dashboard CR.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
