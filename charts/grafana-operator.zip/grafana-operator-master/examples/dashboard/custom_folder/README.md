---
title: "Custom dashboard folder"
linkTitle: "Custom dashboard folder"
---

This example shows how to add assign a dashboard to a folder through the dashboard resource,
avoiding the use of the GrafanaFolder resource.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
