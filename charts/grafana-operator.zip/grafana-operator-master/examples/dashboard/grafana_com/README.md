---
title: "Dashboard from grafana.com/dashboards"
linkTitle: "Dashboard from grafana.com/dashboards"
---

Shows how to obtain the dashboard definition from [grafana.com/dashboards](https://grafana.com/dashboards).

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
