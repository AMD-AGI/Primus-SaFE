---
title: "Jsonnet"
linkTitle: "Jsonnet"
---

A basic deployment of Grafana with a dashboard fom jsonnet.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
