---
title: "Dashboard from URL"
linkTitle: "Dashboard from URL"
---

Shows how to obtain the dashboard definition (json) from an external url.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
