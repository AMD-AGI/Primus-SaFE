---
title: "Dashboard with external dependencies"
linkTitle: "Dashboard with external dependencies"
---

This example shows how to obtain the dashboard definition (json) from provided gzip archived project with dependencies:

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
