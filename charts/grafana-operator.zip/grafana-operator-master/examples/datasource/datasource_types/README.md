---
title: "Datasource types"
linkTitle: "Datasource types"
---

This example shows different types of datasources and how to configure them.

{{< readfile file="prometheus.yaml" code="true" lang="yaml" >}}
{{< readfile file="postgresql.yaml" code="true" lang="yaml" >}}
