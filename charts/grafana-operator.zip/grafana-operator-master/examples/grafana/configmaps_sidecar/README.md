---
title: "Dashboard from configmap via sidecar example"
linkTitle: "Dashboard from configmap via sidecar example"
---

Using the [kiwigrid/k8s-sidecar](https://github.com/kiwigrid/k8s-sidecar) to watch for configmaps and import their
contents as dashboards.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
