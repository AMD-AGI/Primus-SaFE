---
title: "Admin Credentials Secret"
linkTitle: "Admin Credentials from a Secret"
---

This example shows how to provide Grafana admin credentials from an existing secret.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
