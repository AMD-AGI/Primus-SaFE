---
title: "Ingress http"
linkTitle: "Ingress http"
---

A very basic ingress that should only be used for testing.
Always always use https.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
