---
title: "k3d example"
linkTitle: "k3d example"
---

A basic deployment of Grafana in k3d/k3d making use of the built-in Ingress controller.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
