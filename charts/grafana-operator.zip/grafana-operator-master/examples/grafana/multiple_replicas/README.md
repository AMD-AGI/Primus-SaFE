---
title: "Database and Multiple replicas"
linkTitle: "Database and Multiple replicas"
---

This example shows how to run multiple replicas of Grafana sharing a PostgreSQL database.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
