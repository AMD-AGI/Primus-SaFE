---
title: "OpenShift Oauth proxy"
linkTitle: "OpenShift Oauth proxy"
---
An example that uses an auth proxy to enforce authentication.

{{% alert title="Note" color="primary" %}}
this example currently only works on OpenShift
{{% /alert %}}

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
