---
title: "Adding a Persistent Volume"
linkTitle: "Adding a Persistent Volume"
---

A basic deployment of Grafana with a persistent volume attached using existing Storage Class.

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
