---
title: "Mute timing"
weight: 60
tags:
  - Alerting
---

Shows how to create a mute timing.

To view the entire configuration that you can do within Mute Timings, look at our [API documentation](/docs/api/#grafanamutetimingspec).

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
