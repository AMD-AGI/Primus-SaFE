---
title: "Notification template"
weight: 60
tags:
  - Alerting
---

Shows how to create a notification template.

To view the entire configuration that you can do within Notification Template, look at our [API documentation](/docs/api/#grafananotificationtemplatespec).

{{< readfile file="resources.yaml" code="true" lang="yaml" >}}
