# Hugo

## Installing and running Hugo

```shell
cd hugo && npm ci && cd -
```

To look at your changes with hot reload:

```shell
make hugo-dev
```

To detect broken internal links:

```shell
make muffet-dev
```
